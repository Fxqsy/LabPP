package org.example

import org.jsoup.Jsoup


fun procesareJsoup(url : String) : MutableMap<String,MutableMap<String,String>>{
    var documentHtml = Jsoup.connect(url).get()
    var lista = mutableMapOf<String , MutableMap<String,String>>()

    val iteme = documentHtml.select("item")
    for(item in iteme){
        val titlu = item.select("title").text()

        var deAdaugat = mutableMapOf("Link" to item.select("link").text(),
            "Descriere" to item.select("description").text(),
            "Data Publicatiei" to item.select("pubDate").text())
        lista.put(titlu, deAdaugat)

    }
    return lista
}


fun main(){
    val url = "http://rss.cnn.com/rss/edition.rss"
    val lista = procesareJsoup(url)
    lista.forEach{
        println(it.key+": ")
        println(it.value["Link"])
        println(it.value["Descriere"])
        println(it.value["Data Publicatiei"])
    }
}

