package org.example

import java.io.File
import org.jsoup.Jsoup

fun main(){
    val fisier = File("book.txt")
    val text = fisier.readText()

    //ELiminarea nr de pagina
    var rezFaraPagina= ""
    fisier.forEachLine {
        for(litera in it){
            if(! (litera.toString() == " " || litera in 0..9 || litera.toString() == "\n") ) // verif daca linia este formata doar din spatii, cifre sau \n
                rezFaraPagina += it //adaugam daca se intampla sa gasim un caracter diferit de cele verificate mai sus
        }
    }

    //Eliminarea spatiilor  si \n multiple
    var rez = ""
    var prevCh = ""

    for(litera in rezFaraPagina){
        if(!(litera.toString() == " " && prevCh == " ") && !(litera.toString() == "\n" && prevCh == "\n") )
            rez += litera
        prevCh = litera.toString()
    }
    print(rez)
}